import { Directive,ElementRef, Input } from '@angular/core';

@Directive({
  selector: '[appBgcolor]'
})
export class BgcolorDirective {
  @Input() appBgcolor:any;
  constructor(private el:ElementRef) {}
    ngOnInit(){
      this.el.nativeElement.style.backgroudColor= this.appBgcolor
    }

}

import { NgModule } from "@angular/core";
// import { ISchoolComp } from "./ischool.component";
import { ISchoolRegion } from "./ischoolregion.pipe";
import { BgcolorDirective } from "./bgcolor.directive";

@NgModule({
    declarations : [  ISchoolRegion, BgcolorDirective],
    exports : [ ISchoolRegion, BgcolorDirective]
})
export class ISchoolModule{
    
}
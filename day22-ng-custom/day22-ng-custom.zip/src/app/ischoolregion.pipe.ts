import { Pipe } from "@angular/core";

@Pipe({
    name : 'region'
})
export class ISchoolRegion{
    transform(...args:any){
        return args[0]+" is from "+args[1]+"ern part of India";
    }
}
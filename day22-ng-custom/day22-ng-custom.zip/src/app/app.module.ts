import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ISchoolRegion } from './ischoolregion.pipe';
import { BgcolorDirective } from './bgcolor.directive';
import { ISchoolModule } from './ischool.module';

@NgModule({
  declarations: [
    AppComponent, ISchoolRegion, BgcolorDirective
  ],
  imports: [ BrowserModule, ISchoolModule],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
